module.exports={
    mongoURI:process.env.MONGO_URI
}