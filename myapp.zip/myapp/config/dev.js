module.exports={
    mongoURI:'mongodb+srv://test:0000@cluster0.dihw999.mongodb.net/test'
}